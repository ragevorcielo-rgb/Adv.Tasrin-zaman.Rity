# Website

This repository contains your static website (HTML/CSS/JS/images) prepared for deployment on **GitHub Pages**.

## Quick Start

1. Create a new repository on GitHub (public or private).
2. Push these files to the repository root.
3. Go to **Settings → Pages** and ensure **Source: GitHub Actions** is selected.
4. GitHub Actions will build and deploy automatically from the workflow in `.github/workflows/pages.yml`.
5. Your site will be available at `https://<your-username>.github.io/<your-repo>/` (or at the custom domain you configure).

## Local Preview

Just open `index.html` in your browser. No build step required.

## Project Structure

- `index.html` – main page
- `*.css`, `*.js` – styles and scripts
- `deepseek_images/` – images
- `.github/workflows/pages.yml` – GitHub Pages deploy workflow

## Notes

- If you use absolute paths, ensure they work both locally and on GitHub Pages (prefer relative paths like `./assets/...`). 
- To use a **custom domain**, add a `CNAME` file at the repo root with your domain name.
